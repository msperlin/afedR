#' # About New Edition {-}
#' 
#' The first edition of this book was published in
#'   
#' The format of the book has changed significantl
#' 
#' Three new chapters where added to this book, in
#' 
#' For all R teachers in the world, this and all f
#' 
#' I hope you enjoy reading this book and, based o
#' 
#' 